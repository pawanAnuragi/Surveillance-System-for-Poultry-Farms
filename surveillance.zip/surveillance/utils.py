import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import os

def send_alert(animal_name, receiver_email, image_path):
    sender_email = "pawananuragi167@gmail.com"  # Replace with your email address
    password = "aior fsiq vigr yciw"  # Replace with your app-specific password

    message = MIMEMultipart()   # Create the email message
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = f"Alert: {animal_name} Detected!"

    body = f"A {animal_name} has been detected on the poultry farm. Please check the attached image and the surveillance system."
    message.attach(MIMEText(body, "plain"))

    try: # Attach the image
        with open(image_path, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())
        
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f"attachment; filename= {os.path.basename(image_path)}",
        )
        message.attach(part)

    except Exception as e:
        print(f"Error attaching image: {e}")
    
    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)   # Connect to the SMTP server
        server.starttls()  # Upgrade the connection to encrypted SSL/TLS connection
        server.login(sender_email, password)  # Log in to the server
        server.sendmail(sender_email, receiver_email, message.as_string()) 
        server.close()  # Close the connection
        print("Alert sent successfully")
    except Exception as e:
        print(f"Error: {e}")
